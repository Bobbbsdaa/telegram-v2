# ZadrottzGram 2.0

Запуск: `npm install` → `npm start` → http://localhost:3000

## Что внутри
- `server.js` — сервер (express + socket.io), данные в `data/db.json`, вложения в `data/uploads`, аватарки в `data/avatars`
- `public/index.html` — весь клиент в одном файле

## Хостинг на Render
- Build Command: `npm install`  ·  Start Command: `npm start`
- Бесплатный Render стирает диск при каждом перезапуске — аккаунты и чаты пропадут.
  Чтобы данные жили, подключите Render Disk (платно), смонтируйте в `/var/data` и задайте переменную `DATA_DIR=/var/data`.
- Микрофон (голосовые) работает только по HTTPS — на Render он есть.

## Приватность
Сообщение отправляется только в «комнату» двух участников; сервер сам определяет, кто вы, по токену.
Пароли хранятся хэшем (scrypt). Старые пароли из users.json не переносились.
